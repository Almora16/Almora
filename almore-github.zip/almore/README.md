# Almore – Online Boutique

Single-page boutique website (HTML, CSS, JavaScript). No build step, no dependencies.

## Live on GitHub Pages
1. Create a new repository and upload all files from this folder.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, branch **main**, folder **/ (root)**, then Save.
4. After a minute the site is live at `https://<your-username>.github.io/<repo-name>/`.

## Edit
- Products: `const P=[...]` in `index.html`
- Photos: `const IM={...}` (base64)
- Instagram link: search for `your_instagram_id`
